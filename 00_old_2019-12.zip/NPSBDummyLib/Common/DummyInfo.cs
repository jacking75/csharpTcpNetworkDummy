﻿namespace NPSBDummyLib
{
    public class DummyInfo
    {
        public string RmoteIP;
        public int RemotePort;
        public int DummyCount;
        public int PacketSizeMax;
        public bool IsRecvDetailProc;          // 받기 상세 처리
    }
}
